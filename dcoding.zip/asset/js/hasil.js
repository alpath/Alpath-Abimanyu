$(function(){
    //fungsi dibawah hanya berjalan untuk semua tag <a> yang diawali (^) dengan hash (#)
    $('a[href^="#"]').on('click', function(e){
    	<br><br>
    });
});
	
//masukkan ke dalam kurung kurawalnya $(a[href^])......
$target = $(this.hash);

//masukkan baris coding ini dibawahnya $target ......
$jarak = 0;
$('html, body').stop().animate(
    {
        'scrollTop' : $target.offset().top - $jarak
    },
    600;return false, //durasi dalam milisekon
    'swing', //efek transisi (opsi : swing / linear)
    function(){
        window.location.hash = target;
    }
);

