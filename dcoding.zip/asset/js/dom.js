
const cardimg = document.querySelector('.cardimg');
const jumb = document.querySelector('.glone');
const thums = document.querySelectorAll('.thum');

cardimg.addEventListener('click',function(e)
{
	if (e.target.className ==  'thum') {
		jumb.src = e.target.src;
		jumb.classList.add('fade');
		setTimeout(function() {
			jumb.classList.remove('fade');
		}, 500);

		thums.forEach(function(thum){
			thum.className = 'thum';
		});

		e.target.classList.add('active');
	}
});
	
	
		var kate1 = { 
					namaKate : 'Hobi dan Minat +',
					namaKate2 : 'Kompetensi +',
					namaKate3 : 'Kemampuan Atau Skill +',
					namaKate4 : 'Kemampuan Atau Skill +',
					deskripsi : 'Saya sangat suka membaca buku tentang komputer, komik, dan fisika. Saya juga memiliki hobbi olahraga salah satunya lari pagi atau pun sore.',
					deskripsi2 : 'Mengikuti Pelatihan Komputer Kec. Air Batu, Mengikuti LKS Kabupaten IT Administrator, Mengikuti LKS Provinsi IT Administrator, Mengikuti Dicoding Chatbot, Mengikuti Lomba Blog Mie Ayam Mahmod.',
					deskripsi3 : 'Saya telah membuat suatu apliaksi web organisasi, web pendaftaran anggota, web blog, web learning, dan web e-commercial.',
					deskripsi4 : 'Saya menguasi html, css, dan js untuk pengembangan disain web.',
					gbkate1 : function() {
						return '<h4 class="textjd">' + this.namaKate + '</h4>' + '<p class="textds">' + this.deskripsi + '</p>';
					},
					gbkate2 :  function() {
						return '<h4 class="textjd">' + this.namaKate2 + '</h4>' + '<p class="textds">' + this.deskripsi2 + '</p>';
					},
					gbkate3 :  function() {
						return '<h4 class="textjd">' + this.namaKate3 + '<i class="text-danger">Web Develpoer</i></h4>' + '<p class="textds">' + this.deskripsi3 + '</p>';
					},
					gbkate4 :  function() {
						return '<h4 class="textjd">' + this.namaKate4 + '<i class="text-danger">Web Dsaigner</i></h4>' + '<p class="textds">' + this.deskripsi4 + '</p>';
					}
				};

		var cp = {
				judul : 'Contac Person',
				email : 'yudibudi00119922@gmail.com',
				hp : '082274164781',
				alamat : 'Kab. Asahan, Kec. Air Batu, Hessa Air Genting dsn 3, kode pos 21272',
				ig : 'alpath0011',
				cpgb :  function () {
					return '<h4 class="textjd">' + this.judul + '</h4>' + '<p p class="textds garis"><i class="text-danger">Email </i> | ' + this.email + '</p></br>'+ '<p p class="textds garis"><i class="text-danger">No Hp/ Wa </i> | ' + this.hp + '</p></br>' + '<p p class="textds garis"><i class="text-danger">Instagram </i> | ' + this.ig + '</p></br>' + '<p p class="textds garis"><i class="text-danger">Alamat </i> | ' + this.alamat + '</p></br>';
				}
			};

	function DataDiri() {
		document.getElementById('ubah').innerHTML= kate1.gbkate1() + kate1.gbkate2() + kate1.gbkate3() + kate1.gbkate4();
		document.getElementById('ubah').style='padding-top: 45px; width: 350px; margin: auto;';
	}

	function contac() {
		document.getElementById('ubah').innerHTML = cp.cpgb();
		document.getElementById('ubah').style='padding-top: 100px; width: 350px; margin: auto;';
	}